package se233.chapter1.model.character;

public enum DamageType {
    physical,
    magical

}
